#include "aboutmac.h"

aboutMac::aboutMac(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

aboutMac::~aboutMac()
{

}
