#include "variblewidget.h"

varibleWidget::varibleWidget(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

varibleWidget::~varibleWidget()
{

}
