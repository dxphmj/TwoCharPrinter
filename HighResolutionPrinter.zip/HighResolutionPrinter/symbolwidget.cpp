#include "symbolwidget.h"

symbolWidget::symbolWidget(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

symbolWidget::~symbolWidget()
{

}
