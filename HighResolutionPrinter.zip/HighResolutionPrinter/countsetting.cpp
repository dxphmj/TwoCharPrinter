#include "countsetting.h"

countSetting::countSetting(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);

	//ui.counterOneLab->setStyleSheet("font: bold; font-size:25px;color:rgb(255,255,255)"); 
	//ui.currentVal1Lab->setStyleSheet("font: bold; font-size:25px;color:rgb(255,255,255)"); 
	//ui.curValRed1But->setStyleSheet("font: bold; font-size:25px;color:rgb(255,255,255)"); 
    //ui.currentValShow1Lab->setStyleSheet("font: bold; font-size:25px;color:rgb(255,255,255)"); 
	//ui.curValAdd1But->setStyleSheet("font: bold; font-size:25px;color:rgb(255,255,255)"); 
	//QLabel{
	//	font: bold; font-size:25px;
	//	color:rgb(255,255,255);
	//};
}

countSetting::~countSetting()
{

}
