#include "timecustom.h"

timeCustom::timeCustom(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

timeCustom::~timeCustom()
{

}
